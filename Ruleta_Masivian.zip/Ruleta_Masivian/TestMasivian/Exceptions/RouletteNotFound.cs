using System;

namespace TestMasivian.Exceptions
{
    public class RouletteNotFound : Exception
    {
        
    }
}