using System;

namespace TestMasivian.Exceptions
{
    public class NotAllowedOpenException : Exception
    {
        
    }
}