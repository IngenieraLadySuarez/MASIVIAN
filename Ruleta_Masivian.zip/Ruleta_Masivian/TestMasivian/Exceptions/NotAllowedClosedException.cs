using System;

namespace TestMasivian.Exceptions
{
    public class NotAllowedClosedException : Exception
    {
        
    }
}