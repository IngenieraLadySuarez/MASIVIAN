using System;

namespace TestMasivian.Exceptions
{
    public class RouletteClosedException : Exception
    {
        
    }
}