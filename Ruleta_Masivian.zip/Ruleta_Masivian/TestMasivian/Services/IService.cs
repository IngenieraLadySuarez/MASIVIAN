namespace TestMasivian.Services
{
    public interface IService
    {
        
    }
}