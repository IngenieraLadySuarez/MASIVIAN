using System.ComponentModel.DataAnnotations;

namespace TestMasivian.DTO
{
    public class BetRequest
    {
        [Range(0, 40)]
        public int position { get; set; }
        
        [Range(0.5d, maximum:100000)]
        public double money { get; set; }
    }
}