namespace TestMasivian.Repositories
{
    public interface IRepository
    {
        
    }
}